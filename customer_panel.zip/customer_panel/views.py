from django.shortcuts import render
from django.db import IntegrityError
from django.shortcuts import render, redirect
from django.shortcuts import get_object_or_404, redirect
from admin_panel.models import Language,Genre,Movie
from admin_panel.models import WebSeries , Season ,Episode
from .models import CustomerRegister
from django.http import JsonResponse
from django.contrib import messages
from .models import CustomerRegister,SubscriptionPlan, CustomerSubscription
from django.utils import timezone
from django.shortcuts import get_object_or_404, redirect



def has_active_subscription(customer):
    return CustomerSubscription.objects.filter(
        customer=customer,
        is_active=True,
        end_date__gte=timezone.now()
    ).exists()



def customer_register_page(request):
    if request.method == "POST":
       
        fname = request.POST.get('customer_first_name')
        lname = request.POST.get('customer_last_name')
        u_email = request.POST.get('customer_email')
        u_username = request.POST.get('customer_username') 
        u_mobileno = request.POST.get('customer_mobileno')
        u_pwd = request.POST.get('customer_password')
        u_pic = request.FILES.get('customer_profile_pic')

        #  Save it to the Database
        new_customer = CustomerRegister(
            customer_first_name=fname,
            customer_last_name=lname,
            customer_email=u_email,
            customer_username=u_username, # SAVE THE USERNAME HERE
            customer_mobileno=u_mobileno,
            customer_password=u_pwd,
            customer_profile_pic=u_pic
        )
        try:
           new_customer.save()
        except IntegrityError:
          # Handle the error, e.g., redirect back with a message
         print("Email already exists!")

        # After saving, send them to the login page
        return redirect('/customer_panel/customer_login_page/')
    
    return render(request, 'customer_panel/Internship28-octOR.html')




def customer_login_page(request):
    if request.method == "POST":
        username_entered = request.POST.get('customer_entered_username')
        password_entered = request.POST.get('customer_entered_password')

        try:
            customer = CustomerRegister.objects.get(customer_username=username_entered, customer_password=password_entered)
            
            # Store the Customer's ID in the session
            request.session['customer_id'] = customer.id 
            
            return redirect('/customer_panel/customer_dashboard_page/') 
            
        except CustomerRegister.DoesNotExist:
            return render(request, 'customer_panel/Internship28-octOL.html', {'error': 'Invalid Credentials'})

    return render(request, 'customer_panel/Internship28-octOL.html')



def customer_dashboard_page(request):

    customer_id = request.session.get('customer_id')
    customer = CustomerRegister.objects.get(id=customer_id)

    languages = Language.objects.all()
    genres = Genre.objects.all()
    
    return render(request, 'customer_panel/Internship4-octOD.html', {
        'customer': customer, # Pass the customer object here
        'languages': languages,
        'genres': genres
    })

def customer_update_profile(request):
    if request.method == "POST":

        customer_id = request.session.get('customer_id')
        customer = CustomerRegister.objects.get(id=customer_id)

        # Update text fields
        customer.customer_first_name = request.POST.get('customer_modal_first_name')
        customer.customer_last_name = request.POST.get('customer_modal_last_name')
        customer.customer_email = request.POST.get('customer_modal_email')
        
        # SAVE THE USERNAME HERE
        customer.customer_username = request.POST.get('customer_modal_username')

        # SAFELY UPDATE PROFILE PIC
        new_pic = request.FILES.get('customer_profile_pic')
        if new_pic: # Only updates if you actually chose a new file
            customer.customer_profile_pic = new_pic

        customer.save()
        return redirect('/customer_panel/customer_dashboard_page/')
    


def customer_movie_page(request):
    customer_id = request.session.get('customer_id')
    customer = CustomerRegister.objects.get(id=customer_id)

    movies = Movie.objects.all().order_by('-id')
    languages = Language.objects.all()
    genres = Genre.objects.all()

    subscription_status = has_active_subscription(customer)

    return render(request, 'customer_panel/Internship13-novOM.html', {
        'customer': customer,
        'movies': movies,
        'languages': languages,
        'genres': genres,
        'has_subscription': subscription_status
    })






# customer_panel/views.py

def customer_web_series_page(request):
    customer_id = request.session.get('customer_id')
    customer = CustomerRegister.objects.get(id=customer_id)
    
    # 1. Get filter IDs from the URL
    lang_id = request.GET.get('language')
    genre_id = request.GET.get('genre')

    # 2. Start with all web series
    series_list = WebSeries.objects.all().order_by('-created_at')

    # 3. Apply filters using the CORRECT field names from your error message
    if lang_id:
        # Changed 'language_id' to 'series_language_id'
        series_list = series_list.filter(series_language_id=lang_id)
        
    if genre_id:
        # Changed 'genre_id' to 'series_genre_id'
        series_list = series_list.filter(series_genre_id=genre_id)

    # 4. Fetch all records for the dropdowns
    languages = Language.objects.all()
    genres = Genre.objects.all()
    subscription_status = has_active_subscription(customer)

    

    return render(request, 'customer_panel/Internship6-decOW.html', {
        'all_series': series_list,
        'customer': customer,
        'languages': languages,
        'genres': genres,
        'selected_lang': lang_id,
        'selected_genre': genre_id,
        'has_subscription': subscription_status

    })


# customer_panel/views.py

def get_episodes_for_edit(request):
    series_id = request.GET.get('series_id')
    season_id = request.GET.get('season_id')  # 1. Add this line to capture season_id
    
    # 2. Update filter to use BOTH series_id and season_id
    if season_id:
        episodes = Episode.objects.filter(series_id=series_id, season_id=season_id)
    else:
        episodes = Episode.objects.filter(series_id=series_id)
    
    episode_list = []
    for ep in episodes:
        episode_list.append({
            'title': ep.episode_title,
            'url': ep.video_url,
            'image': ep.episode_banner.url if ep.episode_banner else None,  # Add banner URL
            'season_name': ep.season.season_name if ep.season else "S1"
        })
    return JsonResponse({'episodes': episode_list})

def customer_profile_settings_page(request):
    customer_id = request.session.get('customer_id')
    customer = CustomerRegister.objects.get(id=customer_id)
    return render(request, 'customer_panel/Internship5-decOP.html', {
        'customer': customer  # Pass the customer object here
    })

def Customerchange_password(request):
    if request.method == "POST":
        current_pw = request.POST.get('current_password')
        new_pw = request.POST.get('new_password')
        confirm_pw = request.POST.get('confirm_password')

        # 1. Get the admin from the session
        customer_id = request.session.get('customer_id')
        try:
            customer = CustomerRegister.objects.get(id=customer_id)
            
            # 2. Check if passwords match
            if new_pw != confirm_pw:
                messages.error(request, "New passwords do not match!")
            
            # 3. Verify current password and Save
            elif customer.customer_password == current_pw:
                customer.customer_password = new_pw
                customer.save()
                messages.success(request, "Password updated successfully!")
            else:
                messages.error(request, "Current password is incorrect.")
                 
        except CustomerRegister.DoesNotExist:
            return redirect('/customer_panel/customer_login_page/')

    # 4. THIS PREVENTS THE ERROR: It sends you back to the settings page
    return redirect('/customer_panel/customer_profile_settings_page/')

from django.shortcuts import render, get_object_or_404


def Video_player_view(request, movie_id):
    customer_id = request.session.get('customer_id')
    if not customer_id:
        return redirect('/customer_panel/customer_login_page/')

    customer = CustomerRegister.objects.get(id=customer_id)

    if not has_active_subscription(customer):
        return redirect(
            f"/customer_panel/subscription_plans/?c_type=movie&c_id={movie_id}"
        )

    movie = get_object_or_404(Movie, id=movie_id)
    return render(request, 'customer_panel/internshio31-decVideoplayer.html', {
        'movie': movie,
        'customer': customer
    })



# customer_panel/views.py line 254
def web_series_player_view(request, series_id):

    customer_id = request.session.get('customer_id')
    if not customer_id:
        return redirect('/customer_panel/customer_login_page/')

    customer = CustomerRegister.objects.get(id=customer_id)

    has_active_subscription = CustomerSubscription.objects.filter(
        customer=customer,
        is_active=True,
        end_date__gte=timezone.now()
    ).exists()

    if not has_active_subscription:
        return redirect(
            f"/customer_panel/subscription_plans/?c_type=series&c_id={series_id}"
        )

    series = get_object_or_404(WebSeries, id=series_id)
    seasons = Season.objects.filter(series=series)

    return render(request, 'customer_panel/internship01-janweb_series_page.html', {
        'series': series,
        'seasons': seasons,
        'customer': customer
    })



def subscription_plans_page(request):
    customer_id = request.session.get('customer_id')
    customer = get_object_or_404(CustomerRegister, id=customer_id)
    
    # Capture the content info from the "Unlock" button click
    c_type = request.GET.get('c_type', 'movie') # Default to movie if not specified
    c_id = request.GET.get('c_id', 0)
    
    plans = SubscriptionPlan.objects.all()
    
    return render(request, 'customer_panel/internship03-jansubscription.html', {
        'customer': customer,
        'plans': plans,
        'c_type': c_type,
        'c_id': c_id
    })






def process_subscription(request, plan_id, c_type, c_id):

    customer_id = request.session.get('customer_id')
    if not customer_id:
        return redirect('/customer_panel/customer_login_page/')

    customer = CustomerRegister.objects.filter(id=customer_id).first()
    plan = SubscriptionPlan.objects.filter(id=plan_id).first()

    if not customer or not plan:
        messages.error(request, "Invalid subscription request.")
        return redirect('/customer_panel/subscription_plans/')

    # Deactivate previous subscriptions
    CustomerSubscription.objects.filter(
        customer=customer,
        is_active=True
    ).update(is_active=False)

    # Activate new subscription
    CustomerSubscription.objects.create(
        customer=customer,
        plan=plan,
        is_active=True
    )

    # Redirect back to content
    if c_type == 'series':
        return redirect('web_series_player', series_id=c_id)

    if c_type == 'movie':
        return redirect('video_player_view', movie_id=c_id)

    return redirect('/customer_panel/customer_dashboard_page/')

